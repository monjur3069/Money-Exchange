package com.example.money_exchange

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
