import 'package:flutter/material.dart';
import 'package:money_exchange/money_exchange_calculator/claculate.dart';


class MoneyExchange extends StatefulWidget {
  static const String routeName = '/exchange';
  final String msg;
  const MoneyExchange({Key? key,required this.msg}) : super(key: key);

  @override
  State<MoneyExchange> createState() => _MoneyExchangeState();
}

class _MoneyExchangeState extends State<MoneyExchange> {

  final _moneyController = TextEditingController();

  double _result = 0.0;


  @override
  void dispose() {
    _moneyController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.msg),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('BDT'),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 80.0,vertical: 20),
              child: TextField(
                keyboardType: TextInputType.number,
                controller: _moneyController,
                decoration: const InputDecoration(
                    filled: true,
                    fillColor: Colors.transparent,
                    labelText: 'BDT'
                ),
              ),
            ),
            const Text('To'),
            SizedBox(height: 15,),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                    onPressed: (){
                      _calculate(ConversionType.DOLLAR);
                    },
                    child: const Text('US Dollar')
                ),
                ElevatedButton(
                    onPressed: (){
                      _calculate(ConversionType.GBP);
                    },
                    child: const Text('GBP')
                ),
                ElevatedButton(
                    onPressed: (){
                      _calculate(ConversionType.EURO);
                    },
                    child: const Text('EURO')
                ),
              ],
            ),
            SizedBox(height: 20,),
            Text(_result.toStringAsFixed(2),style: Theme.of(context).textTheme.headline1,)


          ],
        ),
      ),

    );
  }

  _calculate(ConversionType type)
  {
    final input = double.parse(_moneyController.text);
    var rate = 0.0;
    switch(type){
      case ConversionType.DOLLAR:
        rate = dollarToBdt;
        break;
      case ConversionType.GBP:
        rate = gbtToBdt;
        break;
      case ConversionType.EURO:
        rate = euroToBdt;
        break;
    }
    setState(() {
      _result = input/rate;
    });
  }


}
