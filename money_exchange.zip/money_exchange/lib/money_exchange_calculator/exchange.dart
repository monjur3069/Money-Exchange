import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'claculate.dart';


class MoneyExchange extends StatefulWidget {
  static const String routeName = '/exchange';
  final String msg;

  const MoneyExchange({Key? key, required this.msg}) : super(key: key);

  @override
  State<MoneyExchange> createState() => _MoneyExchangeState();
}

class _MoneyExchangeState extends State<MoneyExchange> {

  final _moneyController = TextEditingController();
  final _dollarController = TextEditingController();
  final _gbpController = TextEditingController();
  final _euroController = TextEditingController();
  double _result = 0.0;


  @override
  void dispose() {
    _moneyController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.msg),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Icon(Icons.money, color: Colors.green,),
                    SizedBox(width: 10.w,),
                    Text('BDT', style: TextStyle(color: Colors.green,
                        fontSize: 25,
                        fontWeight: FontWeight.bold),),
                  ],
                ),
                SizedBox(height: 10.h,),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    keyboardType: TextInputType.number,
                    controller: _moneyController,
                    decoration: const InputDecoration(
                        filled: true,
                        fillColor: Colors.transparent,
                        labelText: 'Enter amount of BDT'
                    ),
                  ),
                ),
                SizedBox(height: 15.h,),
                Text('To', style: TextStyle(color: Colors.green,
                    fontSize: 25,
                    fontWeight: FontWeight.bold),),
                SizedBox(height: 15.h,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextField(
                            keyboardType: TextInputType.number,
                            controller: _dollarController,
                            decoration: const InputDecoration(
                                filled: true,
                                fillColor: Colors.transparent,
                                labelText: 'Currency'
                            ),
                          ),
                          SizedBox(height: 10,),
                          ElevatedButton(
                              onPressed: () {
                                _calculate(ConversionType.DOLLAR);
                              },
                              child: const Text('US Dollar')
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width:10.w),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextField(
                            keyboardType: TextInputType.number,
                            controller: _gbpController,
                            decoration: const InputDecoration(
                                filled: true,
                                fillColor: Colors.transparent,
                                labelText: 'Currency'
                            ),
                          ),
                          SizedBox(height: 10.h,),
                          ElevatedButton(
                              onPressed: () {
                                _calculate(ConversionType.GBP);
                              },
                              child: const Text('GBP')
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width:10.w),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          TextField(
                            keyboardType: TextInputType.number,
                            controller: _euroController,
                            decoration: const InputDecoration(
                                filled: true,
                                fillColor: Colors.transparent,
                                labelText: 'Currency'
                            ),
                          ),
                          SizedBox(height: 10.h,),
                          ElevatedButton(
                              onPressed: () {
                                _calculate(ConversionType.EURO);
                              },
                              child: const Text('EURO')
                          ),
                        ],
                      ),
                    ),


                  ],
                ),
                SizedBox(height: 20.h,),
                Text(_result.toStringAsFixed(2), style: Theme
                    .of(context)
                    .textTheme
                    .headline1,)


              ],
            ),
          ),
        ),
      ),

    );
  }

  _calculate(ConversionType type) {
    final input = double.parse(_moneyController.text);
    var rate = 0.0;
    switch (type) {
      case ConversionType.DOLLAR:
        rate = double.parse(_dollarController.text);
        break;
      case ConversionType.GBP:
        rate = double.parse(_gbpController.text);
        break;
      case ConversionType.EURO:
        rate = double.parse(_euroController.text);
        break;
    }
    setState(() {
      _result = input / rate;
    });
  }


}
