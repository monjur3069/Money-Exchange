const dollarToBdt = 92.90;
const gbtToBdt = 114.52;
const euroToBdt = 98.56;

enum ConversionType{
  DOLLAR,GBP,EURO
}